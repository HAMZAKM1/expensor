// scripts.js for Expensor

document.addEventListener("DOMContentLoaded", function () {
    // Highlight active navbar link
    const currentPath = window.location.pathname;
    document.querySelectorAll(".navbar-nav .nav-link").forEach(link => {
        if (link.getAttribute("href") === currentPath) {
            link.classList.add("active");
        }
    });

    // Auto-dismiss alert messages
    const alerts = document.querySelectorAll(".alert");
    alerts.forEach(alert => {
        setTimeout(() => alert.classList.add("fade"), 4000);
        setTimeout(() => alert.remove(), 5000);
    });

    // Confirm delete if any delete buttons exist
    document.querySelectorAll(".btn-danger").forEach(button => {
        button.addEventListener("click", function (e) {
            if (!confirm("Are you sure you want to delete this expense?")) {
                e.preventDefault();
            }
        });
    });
});
