from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth import authenticate, login, logout
from django.contrib.auth.decorators import login_required
from django.contrib import messages
from django.utils import timezone
from .models import Expense
from .forms import ExpenseForm, RegisterForm
from django.core.paginator import Paginator
from .forms import CategoryForm
from django.db.models import Sum
from .models import Expense, Category
from django.db.models import Count
from django.db.models import Sum, Count, Q
from .models import Expense, Category
from django.contrib.auth.decorators import login_required
from django.shortcuts import render
from django.http import JsonResponse
import json
def home_view(request):
    return render(request, 'tracker/home.html')


# 🔐 Register new user
def register_view(request):
    if request.method == 'POST':
        form = RegisterForm(request.POST)
        if form.is_valid():
            form.save()
            messages.success(request, "🎉 Registration successful. Please log in.")
            return redirect('login')
        else:
            messages.error(request, "❌ Please correct the errors below.")
    else:
        form = RegisterForm()
    return render(request, 'tracker/register.html', {'form': form})

# 🔐 Login user
def login_view(request):
    if request.method == 'POST':
        username = request.POST.get('username')
        password = request.POST.get('password')
        user = authenticate(request, username=username, password=password)
        if user:
            login(request, user)
            next_url = request.GET.get('next', 'dashboard')
            return redirect(next_url)
        else:
            messages.error(request, "❌ Invalid credentials. Please try again.")
    return render(request, 'tracker/login.html')

# 🚪 Logout user
def logout_view(request):
    logout(request)
    messages.success(request, "✅ You have been logged out.")
    return redirect('login')


# 📊 Dashboard with user expenses, total, and pagination




@login_required
def dashboard(request):
    expenses = Expense.objects.filter(user=request.user).order_by('-date')

    # 🔍 Filters
    search = request.GET.get('search', '')
    category_id = request.GET.get('category')
    status = request.GET.get('status')
    month = request.GET.get('month')
    start_date = request.GET.get('start_date')

    if search:
        expenses = expenses.filter(Q(title__icontains=search) | Q(description__icontains=search))

    if category_id:
        expenses = expenses.filter(category_id=category_id)

    if status:
        expenses = expenses.filter(status=status)

    if month:
        try:
            year, month_num = map(int, month.split('-'))
            expenses = expenses.filter(date__year=year, date__month=month_num)
        except:
            pass

    if start_date:
        expenses = expenses.filter(date__gte=start_date)

    # 📄 Export CSV or PDF
    export_type = request.GET.get('export')
    if export_type == 'csv':
        # implement CSV export
        pass
    elif export_type == 'pdf':
        # implement PDF export
        pass

    # 📊 Pagination
    paginator = Paginator(expenses, 10)
    page_number = request.GET.get('page')
    page_obj = paginator.get_page(page_number)

    # 💰 Total for current page
    total = sum(exp.amount for exp in page_obj.object_list)

    # 📂 Category list with expense count
    categories = Category.objects.annotate(expense_count=Count('expense'))

    # 📈 Category-wise total for chart & summary
    category_totals_qs = Expense.objects.filter(user=request.user).values('category__name').annotate(total=Sum('amount'))
    category_totals = {item['category__name']: item['total'] for item in category_totals_qs}

    # 🧠 Most expensive category
    top_category = max(category_totals.items(), key=lambda x: x[1])[0] if category_totals else None

    context = {
        'expenses': page_obj,
        'page_obj': page_obj,
        'total': total,
        'categories': categories,
        'category_totals': category_totals,
        'top_category': top_category,
    }

    return render(request, 'tracker/dashboard.html', context)


@login_required
def expense_list(request):
    user_expenses = Expense.objects.filter(user=request.user)

    # Group by category name and sum
    grouped = user_expenses.values('category__name').annotate(total=Sum('amount'))
    chart_categories = [entry['category__name'] for entry in grouped]
    chart_totals = [entry['total'] for entry in grouped]

    # Annotate categories with expense counts
    categories = Category.objects.annotate(
        expense_count=Count('expense', filter=Q(expense__user=request.user))
    )

    total_spent = user_expenses.aggregate(Sum('amount'))['amount__sum'] or 0

    return render(request, 'tracker/expense_list.html', {
        'categories': categories,
        'chart_categories': chart_categories,
        'chart_totals': chart_totals,
        'total_spent': total_spent,
    })


@login_required
def add_expense(request):
    recent_expenses = Expense.objects.filter(user=request.user).order_by('-date')[:5]
    if request.method == 'POST':
        form = ExpenseForm(request.POST, request.FILES)
        if form.is_valid():
            expense = form.save(commit=False)
            expense.user = request.user
            expense.save()
            messages.success(request, "📝 Expense added successfully.")
            return redirect('add_expense')
    else:
        form = ExpenseForm()
    return render(request, 'tracker/add_expense.html', {
        'form': form,
        'recent_expenses': recent_expenses
    })
@login_required
def edit_expense(request, pk):
    expense = get_object_or_404(Expense, pk=pk, user=request.user)

    if request.method == 'POST':
        form = ExpenseForm(request.POST, request.FILES, instance=expense)
        if form.is_valid():
            form.save()
            messages.success(request, 'Expense updated successfully!')
            return redirect('dashboard')  # or 'expense_list'
        else:
            messages.error(request, 'Please correct the errors below.')
    else:
        form = ExpenseForm(instance=expense)

    return render(request, 'tracker/edit_expense.html', {'form': form, 'expense': expense})

# ✏️ Edit existing expense


# ❌ Delete expense
@login_required
def delete_expense(request, pk):
    expense = get_object_or_404(Expense, pk=pk, user=request.user)
    expense.delete()
    messages.success(request, "🗑️ Expense deleted.")
    return redirect('dashboard')

# 📩 Support page with message handling
def support_view(request):
    if request.method == 'POST':
        name = request.POST.get('name')
        email = request.POST.get('email')
        subject = request.POST.get('subject')
        message = request.POST.get('message')
        # (optional) save to DB or send email here
        messages.success(request, "✅ Your message has been sent!")
    return render(request, 'tracker/support.html')

# 📜 Privacy Policy
def privacy_policy_view(request):
    return render(request, 'tracker/privacy_policy.html')

# 📄 Terms of Service
def terms_view(request):
    return render(request, 'tracker/terms.html')
def add_category(request):
    if request.method == 'POST':
        form = CategoryForm(request.POST)
        if form.is_valid():
            form.save()
            messages.success(request, '✅ Category added successfully.')
            return redirect('add_category')  # or redirect to dashboard
    else:
        form = CategoryForm()
    return render(request, 'tracker/add_category.html', {'form': form})


@login_required
def expense_chart(request):
    # Get expenses of current user grouped by category
    data = Expense.objects.filter(user=request.user).values('category__name').annotate(total=Sum('amount'))

    categories = [item['category__name'] for item in data]
    totals = [float(item['total']) for item in data]

    return render(request, 'tracker/expense_chart.html', {
        'categories': json.dumps(categories),
        'totals': json.dumps(totals)
    })


@login_required
def edit_category(request, id):
    category = get_object_or_404(Category, id=id)
    if request.method == 'POST':
        form = CategoryForm(request.POST, instance=category)
        if form.is_valid():
            form.save()
            messages.success(request, '✅ Category updated.')
            return redirect('dashboard')
    else:
        form = CategoryForm(instance=category)
    return render(request, 'tracker/edit_category.html', {'form': form})

@login_required
def delete_category(request, id):
    category = get_object_or_404(Category, id=id)
    category.delete()
    messages.success(request, '🗑️ Category deleted.')
    return redirect('dashboard')
