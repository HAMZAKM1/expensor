from django.urls import path
from . import views

urlpatterns = [
    # 🏠 Home & Dashboard
    path('', views.home_view, name='home'),
    path('dashboard/', views.dashboard, name='dashboard'),
    path('expenses/', views.expense_list, name='expense_list'),

    # 📈 Charts & Summary
    path('chart/', views.expense_chart, name='expense_chart'),

    # 📂 Categories
    path('add-category/', views.add_category, name='add_category'),
    path('edit-category/<int:id>/', views.edit_category, name='edit_category'),
    path('delete-category/<int:id>/', views.delete_category, name='delete_category'),

    # 💸 Expenses
    path('add/', views.add_expense, name='add_expense'),
    path('edit/<int:pk>/', views.edit_expense, name='edit_expense'),
    path('delete/<int:pk>/', views.delete_expense, name='delete_expense'),

    # 📄 Static pages
    path('privacy-policy/', views.privacy_policy_view, name='privacy_policy'),
    path('terms/', views.terms_view, name='terms'),
    path('support/', views.support_view, name='support'),

    # 🔐 Auth
    path('register/', views.register_view, name='register'),
    path('login/', views.login_view, name='login'),
    path('logout/', views.logout_view, name='logout'),

    # 🔒 Fallback for login_required decorator
    path('accounts/login/', views.login_view),
]
